# Contact and Support

## Contact Channels
- Email: admin@tryjumpstart.com
- Phone: +1 555 123-9823

## Support Hours
Mon-Fri 9:00 AM-5:00 PM CST

## Expected Response Time
Within 1 Business Day

## Order and Account Help
Order tracking: /pages/track-your-order | FAQ: /pages/faqs | Contact support: /pages/contact

## Business Address
91 Canterbury Court
Dover, NH 03820

## Related Policy Links
Link to returns/refunds, shipping, privacy, and subscription terms (if applicable).
