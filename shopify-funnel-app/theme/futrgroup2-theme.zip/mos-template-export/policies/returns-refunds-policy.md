# Returns and Refunds Policy

This policy explains return, exchange, cancellation, and refund terms for purchases from The Honest Herbalist (The Honest Herbalist) on https://honest-test-3.myshopify.com.

## Eligibility
Returned items must satisfy the condition requirements in this section and may be denied if they do not meet policy criteria.

Returns are eligible within 90 days when items are unused, in original packaging, and include proof of purchase.

## Return/Refund Window
Cancellation and return/refund requests must be submitted within the policy windows below.

Returns can be requested within 90 days of delivery, and cancellations requested within 12 hours are eligible for full refund when fulfillment has not started.

## How to Request
Submit requests through the official support channel and include order-identifying details.

Contact support with order details and return reason before sending any item back; unauthorized returns are not accepted.

## Refund Method and Timing
Approved refunds are issued to the original payment method unless required otherwise by law.

Approved refunds are issued to the original payment method after review and may take up to 5 business days to post.

## Fees and Deductions
Shipping charges, handling costs, or condition-based deductions may apply where disclosed.

Return shipping charges are customer responsibility unless the item was incorrect or defective; non-refundable service charges may apply after fulfillment.

## Exceptions
Certain purchases (for example final-sale, custom, or abuse-related orders) may be excluded except where required by law.

Final-sale, refused-delivery, abuse-related, and certain post-delivery loss claims may be excluded or resolved at the business's discretion where law allows.

## Support Contact
For return authorization or refund support, contact admin@tryjumpstart.com.

**Effective date:** 2026-02-27
