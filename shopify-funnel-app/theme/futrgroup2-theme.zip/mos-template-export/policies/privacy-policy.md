# Privacy Policy

This Privacy Policy explains how The Honest Herbalist ("The Honest Herbalist", "we", "us") collects, uses, and shares personal information when you visit or make a purchase from https://honest-test-3.myshopify.com.

- Brand: The Honest Herbalist
- Operator: The Honest Herbalist
- Contact: admin@tryjumpstart.com
- Address: 91 Canterbury Court
Dover, NH 03820
- Effective date: 2026-02-27

## Owner and Controller Identity
The Honest Herbalist is the data controller responsible for personal information handled for The Honest Herbalist.

## Data We Collect
We may collect order, account, support, payment-confirmation, device, and browsing information, including through cookies and similar technologies.

We collect device details, browsing activity, order information (including contact, billing, and shipping details), and support interactions, including analytics and ad-attribution events.

## How We Use Data
We use personal information to provide products/services, process transactions, fulfill orders, communicate with customers, prevent fraud, and improve site and marketing performance.

Personal information is used to operate the store, process payments and shipping, provide support, screen orders for risk or fraud, and improve site and marketing performance.

## How We Share Data
We share data only as needed to operate the business (for example: commerce platform, payment processor, shipping partners, analytics, and customer support providers) or when legally required.

Data is shared only with service providers that support checkout, fulfillment, analytics, and messaging, or when required by law.

## User Choices and Controls
Depending on location, users may have rights to access, correct, delete, or opt out of certain data uses such as targeted advertising. Users can also manage cookie preferences and marketing subscriptions where available.

Customers can opt out of marketing where available and can request access, correction, or deletion by contacting support.

## Security and Retention
We apply reasonable technical and organizational safeguards and retain personal information only for as long as needed for legitimate business and legal purposes.

Reasonable technical and organizational safeguards are applied, and data is retained only as long as needed for business and legal purposes.

## Privacy Contact
For privacy questions or requests, contact admin@tryjumpstart.com.

## Policy Updates and Effective Date
This policy may be updated periodically to reflect operational, legal, or regulatory changes, and updates are published on this page.

**Effective date:** 2026-02-27
