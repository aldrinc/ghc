# Company Information

## Legal Entity
The Honest Herbalist

## Registered/Business Address
91 Canterbury Court
Dover, NH 03820

## Customer-Facing Brand Name
The Honest Herbalist

## Ownership/Operator
The Honest Herbalist

## Business License (Where Required)
TX-1234567

## Support Contact
Email: admin@tryjumpstart.com  
Phone: +1 555 123-9823
