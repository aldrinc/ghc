# Shipping Policy

This policy describes shipping timelines, delivery expectations, and issue handling for orders placed with The Honest Herbalist on https://honest-test-3.myshopify.com.

## Shipping Regions
We ship to the United States and Australia, with worldwide tracked shipping available for many regions.

## Processing Time
Orders are processed on business days and can be affected by weekends, holidays, or high-volume periods.

Typical delivery windows are: USA 1-3 business days, Australia 1-4 business days, Worldwide tracked 4-13 business days, and PO Box or military addresses 4-30 business days.

## Shipping Options and Costs
Available shipping methods and charges are shown at checkout before payment.

Shipping options and costs are shown at checkout, including free shipping routes where available.

## Delivery Estimates
Delivery windows begin after dispatch and are estimates, not guarantees.

Estimated delivery windows vary by destination, including domestic and international ranges shown at checkout.

## Tracking
Tracking details are provided after dispatch when available.

Tracked shipping updates are provided once an order has been dispatched.

## Address Changes
Address or cancellation requests are time-sensitive and may be unavailable after fulfillment starts.

Address changes and cancellation requests must be submitted promptly and cannot be guaranteed after fulfillment begins.

## Lost or Damaged Packages
Customers should report lost, delayed, or damaged shipments promptly so investigation or claim workflows can begin.

Lost, delayed, or damaged delivery issues should be reported to support promptly for claim review and next steps.

## Customs and Duties
Customs processing, import duties, and local taxes for international shipments are governed by destination country requirements.

International customs duties, import taxes, and related fees are the customer's responsibility unless explicitly stated otherwise.

## Return Address
Return shipments must be sent to the return address provided by support after return authorization.

## Shipping Support Contact
For shipping support, contact admin@tryjumpstart.com.

**Effective date:** 2026-02-27
