# Terms of Service

These Terms of Service ("Terms") govern your access to and use of https://honest-test-3.myshopify.com, operated by The Honest Herbalist ("The Honest Herbalist", "we", "us"). By visiting the site or purchasing a product/service, you agree to these Terms.

## Business Identity
- Brand: The Honest Herbalist
- Legal business name: The Honest Herbalist
- Business address: 91 Canterbury Court
Dover, NH 03820

## Offer Scope and Eligibility
Use of this website and related services is conditioned on acceptance of these Terms and posted policy notices.

By using the site or placing an order, customers agree to these Terms and confirm they will comply with applicable laws.

## Pricing and Billing Terms
Prices, promotions, and availability can change without notice unless required by law. Payment authorization is required before order fulfillment.

Prices and charges are shown before purchase confirmation, and payment authorization is required before order fulfillment.

## Fulfillment and Access Terms
We may limit, refuse, or cancel orders when necessary (for example suspected fraud, abuse, or inventory constraints), and we may update or discontinue portions of the service.

Order acceptance, shipping, and service access remain subject to availability, fraud screening, and operational constraints.

## Refund and Cancellation Links
Review applicable refund, cancellation, shipping, and subscription policy pages before purchase.

Refund and cancellation terms are defined in the Returns and Refunds Policy and Shipping Policy available in the site footer.

## Limitations and Disclaimers
The service and content are provided on an "as-is" and "as-available" basis except where prohibited by law.

Services are provided on an as-is and as-available basis to the fullest extent permitted by law.

## Support Contact
Contact: admin@tryjumpstart.com

## Dispute Resolution and Governing Law
To the fullest extent permitted by law, disputes arising from these Terms are resolved through binding arbitration in the United States before one arbitrator.

These Terms are governed by the laws of the United States.

**Effective date:** 2026-02-27
