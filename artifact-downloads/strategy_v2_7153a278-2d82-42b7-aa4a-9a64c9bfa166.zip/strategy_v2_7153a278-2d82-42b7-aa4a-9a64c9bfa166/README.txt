Strategy V2 artifact export for workflow_run_id: 7153a278-2d82-42b7-aa4a-9a64c9bfa166

Files were exported from the artifacts table using exact artifact IDs from workflow artifact refs.

Artifact count: 20

Artifacts:
- stage0_artifact_id -> strategy_v2_stage0 (dc7b69a4-619b-47da-995f-82c09d59657c)
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/01_strategy_v2_stage0__dc7b69a4-619b-47da-995f-82c09d59657c.json
- stage1_artifact_id -> strategy_v2_stage1 (6bb9a3aa-24d4-4b4c-b34d-9ba730410f54)
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/02_strategy_v2_stage1__6bb9a3aa-24d4-4b4c-b34d-9ba730410f54.json
- stage2_artifact_id -> strategy_v2_stage2 (b6c184a7-aa95-48ed-bfbd-8a4ad830de90)
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/03_strategy_v2_stage2__b6c184a7-aa95-48ed-bfbd-8a4ad830de90.json
- awareness_matrix_artifact_id -> strategy_v2_awareness_angle_matrix (182fcf34-8537-43f5-9d77-2220386bce16)
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/04_strategy_v2_awareness_angle_matrix__182fcf34-8537-43f5-9d77-2220386bce16.json
- stage3_artifact_id -> strategy_v2_stage3 (7edd8178-a83e-48b7-a87a-593f63aa1c75)
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/05_strategy_v2_stage3__7edd8178-a83e-48b7-a87a-593f63aa1c75.json
- copy_context_artifact_id -> strategy_v2_copy_context (0ca05eb7-0286-460b-9bef-8053a2598228)
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/06_strategy_v2_copy_context__0ca05eb7-0286-460b-9bef-8053a2598228.json
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/06_strategy_v2_copy_context__0ca05eb7-0286-460b-9bef-8053a2598228__compliance_markdown.md
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/06_strategy_v2_copy_context__0ca05eb7-0286-460b-9bef-8053a2598228__brand_voice_markdown.md
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/06_strategy_v2_copy_context__0ca05eb7-0286-460b-9bef-8053a2598228__mental_models_markdown.md
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/06_strategy_v2_copy_context__0ca05eb7-0286-460b-9bef-8053a2598228__audience_product_markdown.md
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/06_strategy_v2_copy_context__0ca05eb7-0286-460b-9bef-8053a2598228__awareness_angle_matrix_markdown.md
- copy_artifact_id -> strategy_v2_copy (44f11dd8-6485-4ad8-864b-f4049c60297d)
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/07_strategy_v2_copy__44f11dd8-6485-4ad8-864b-f4049c60297d.json
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/07_strategy_v2_copy__44f11dd8-6485-4ad8-864b-f4049c60297d__body_markdown.md
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/07_strategy_v2_copy__44f11dd8-6485-4ad8-864b-f4049c60297d__presell_markdown.md
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/07_strategy_v2_copy__44f11dd8-6485-4ad8-864b-f4049c60297d__sales_page_markdown.md
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/07_strategy_v2_copy__44f11dd8-6485-4ad8-864b-f4049c60297d__headline.txt
- approved_artifact_id -> strategy_v2_copy (0909e7d2-55a0-4573-a5a0-d15dbc365d68)
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/08_strategy_v2_copy__0909e7d2-55a0-4573-a5a0-d15dbc365d68.json
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/08_strategy_v2_copy__0909e7d2-55a0-4573-a5a0-d15dbc365d68__approved_body_markdown.md
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/08_strategy_v2_copy__0909e7d2-55a0-4573-a5a0-d15dbc365d68__approved_presell_markdown.md
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/08_strategy_v2_copy__0909e7d2-55a0-4573-a5a0-d15dbc365d68__approved_sales_page_markdown.md
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/08_strategy_v2_copy__0909e7d2-55a0-4573-a5a0-d15dbc365d68__approved_headline.txt
- v2-01 -> strategy_v2_step_payload (07e52b7a-b744-4e51-a81a-d4c4d5aae487)
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/09_strategy_v2_step_payload__07e52b7a-b744-4e51-a81a-d4c4d5aae487__v2-01.json
- v2-02 -> strategy_v2_step_payload (7639ede8-8812-4662-8671-21c96c7eba40)
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/10_strategy_v2_step_payload__7639ede8-8812-4662-8671-21c96c7eba40__v2-02.json
- v2-03 -> strategy_v2_step_payload (6a8b90cc-5568-4aee-8391-810d68cea597)
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/11_strategy_v2_step_payload__6a8b90cc-5568-4aee-8391-810d68cea597__v2-03.json
- v2-04 -> strategy_v2_step_payload (353bdddd-7a6a-4972-b2e2-a8b1c7a73480)
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/12_strategy_v2_step_payload__353bdddd-7a6a-4972-b2e2-a8b1c7a73480__v2-04.json
- v2-05 -> strategy_v2_step_payload (6386ba1f-483b-48c5-bb9a-198a4703ac2a)
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/13_strategy_v2_step_payload__6386ba1f-483b-48c5-bb9a-198a4703ac2a__v2-05.json
- v2-06 -> strategy_v2_step_payload (64a73ab5-6d5e-42ae-888a-e43aee5affd1)
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/14_strategy_v2_step_payload__64a73ab5-6d5e-42ae-888a-e43aee5affd1__v2-06.json
- v2-07 -> strategy_v2_step_payload (10a572b8-223d-4078-aa1b-2fe1bb8d1194)
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/15_strategy_v2_step_payload__10a572b8-223d-4078-aa1b-2fe1bb8d1194__v2-07.json
- v2-08 -> strategy_v2_step_payload (5a218942-32b8-4c34-a559-37fb69adef62)
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/16_strategy_v2_step_payload__5a218942-32b8-4c34-a559-37fb69adef62__v2-08.json
- v2-08b -> strategy_v2_step_payload (f397a2db-a2bf-444a-bdfe-9dcddfcd5c22)
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/17_strategy_v2_step_payload__f397a2db-a2bf-444a-bdfe-9dcddfcd5c22__v2-08b.json
- v2-09 -> strategy_v2_step_payload (cae2410d-fae7-41d3-b8b2-aac7ee597043)
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/18_strategy_v2_step_payload__cae2410d-fae7-41d3-b8b2-aac7ee597043__v2-09.json
- v2-10 -> strategy_v2_step_payload (87c5b502-909e-4a85-be23-04c081b034f4)
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/19_strategy_v2_step_payload__87c5b502-909e-4a85-be23-04c081b034f4__v2-10.json
- v2-11 -> strategy_v2_step_payload (fac109a7-6302-455b-ba66-90ffcca4cca2)
  - artifact-downloads/strategy_v2_7153a278-2d82-42b7-aa4a-9a64c9bfa166/20_strategy_v2_step_payload__fac109a7-6302-455b-ba66-90ffcca4cca2__v2-11.json
